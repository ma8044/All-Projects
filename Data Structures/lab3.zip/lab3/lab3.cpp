/**
 * @file lab5.cpp
 * @Mustafa Asif 
 * @description This program convert an Infix expression to PostFix and then evaluate it
 * @May 30 2024 
 */
//starter_code_begins
#include<iostream>
#include<string>
#include<exception>
#include<math.h>
#include<ctype.h>

using namespace std;

//=============MyStack Class ================
template <typename T>
class MyStack
{
	private:
		T *array;
		int n;	//number of current elements in the MyStack
		int N;	//Array Size (Capacity)
	public:
		MyStack(int N=50); //we set default capacity of stack as 50
		~MyStack();
		void push(T);	//Push an elemet in the stack
		void pop();	//pop/remove the element at the tos 
		T& top();	//return reference of the top element
		int size();	//return current size of MyStack
		bool empty();	//returns true if the stack is Empty
};
//=============================================
bool isOperator(char); //Function that checks if the input char is an operator
bool isgeq(char, char); //Helper function that compare two operators  and return True if the presedence of first operator is greater than or equal to the second operator
int convertOpToInt (char); //Function that converts operators into int so their precdence can be compared
string infix2postfix(string);   //Function that converts an infix notaiton into a postfix notation (lab4)
float evaluate(string postfix);	 //Function that will evaluate a PostfixExpression and return the result
bool isBalanced(string expression); // Funciton that will check for balanced parentheses 
//==========================================
int main()
{

	while(true)
	{
		string infix;  						//Infix expression
		cout<<"Enter an Infix Expression: ";
		cin>>infix;
		try
		{
			if(infix=="exit") 	break;
			
			else if(!isBalanced(infix)) 
			{
				cout<<"Expression is not Balanced "<<endl;
				continue;
			}

			string postfix = infix2postfix(infix);	//Postfix Expression
			cout<<"The postfix form is: "<<postfix<<endl;
			float ans=evaluate(postfix);			//evaluate the postfix Expresion
			cout<<infix<<"="<<ans<<endl;		//print the final answer
		}
		catch(exception &e)
		{
			cout<<"Exception: "<<e.what()<<endl;
		}
	}

	return EXIT_SUCCESS;
}
//==========================================
//Function that checks if a given char is a valid operator or not.
bool isOperator(char ch)
{
	if( ch=='+' || ch=='-' || ch=='*' || ch=='/' || ch=='^')
		return true;
	else
		return false;
}
//==========================================
//Function that converts operators into an integer so its precdence can be checked
int convertOpToInt (char ch)
{
    if (ch=='+' || ch=='-') return 1;
    if (ch=='*' || ch=='/') return 2;
    if (ch=='^') return 3;
    return 0;
}
//Helper method that compare two operators and return true if first operator
//has greater or equal predence than the second operator
bool isgeq(char opA, char opB)
{
	return (convertOpToInt(opA)>=convertOpToInt(opB));
}
//starter_code_ends
//===============================================================================
// == Define the methods of My Stack and other functions below this line.
//===============================================================================

//Constructor which initializes the stack
template <typename T> MyStack<T>::MyStack(int N){
	this -> N = N; 
	array = new T[N]; //creates an array of size N
	this -> n = 0; //sets the current elements at 0.
}

//Deconstructor
template <typename T> MyStack<T>::~MyStack(){
	delete[] array; //frees the memory held by the dynamic array
}

//Pushes new elements
template <typename T> void MyStack<T>::push(T elem){
	if (n==N) throw logic_error("Stack is Full!"); //Stack overflow error if stack is full
	array[n++] = elem; //Adds the element at the next free index, and increases n by 1.
}

//Pops the element at the top
template <typename T> void MyStack<T>::pop(){
	if (empty()) throw logic_error("Stack is empty!"); //Stack empty error
	n--; //The size decreases meaning that the memory of the index at which the popped element was is no longer accessible.
}

//Checks if stack is empty
template <typename T> bool MyStack<T>::empty(){
	return n==0; //True if stack is empty
}

//Returns element at the top
template <typename T> T& MyStack<T>::top(){
	if (empty()) throw logic_error("Stack is empty!");
	return array[n-1];
}

//Returns the size of stack
template <typename T> int MyStack<T>::size(){
	return n; //n is the size of the stack
}

//Function which checks if an infix expression is balanced
bool isBalanced(string expression){
	MyStack<char> b_Stack; //Creates a stack
	for (int i=0; i<expression.length(); i++){ //iterates through every index in the infix expression
		if (expression[i] == '(') b_Stack.push(expression[i]); //pushes '(' onto stack
		if (expression[i] == ')'){
			if (b_Stack.empty()) return false; //If ')' occurs before '(' returns false
		b_Stack.pop(); //pops the '(' from the stack
		}
	}
	return b_Stack.empty(); //Returns true if expression is balanced
}

//Function which converts the infix to postfix
string infix2postfix(string infix){
	MyStack<char> Stack;
	string postfix = ""; //Creates an empty string
	for (int i=0; i<infix.length(); i++){ //Iterates through the infix expression
		if (isdigit(infix[i])) postfix += infix[i]; //If index is operand, it is added to postfix
		else if (infix[i]=='(') Stack.push(infix[i]); //if index is '(' it is added to postfix
		else if (isOperator(infix[i])){ //If index is operator:
			//While loop stops if stack is empty, top element is '(' or if the top of the stack is an operator with lower precedence.
			while (!Stack.empty() && Stack.top() != '(' && isgeq(Stack.top(), infix[i])) {
				postfix+=Stack.top(); //adds the top of the stack to postfix and pops
				Stack.pop();
			}
			Stack.push(infix[i]); //pushes the new operator onto the stack
			}
		else if (infix[i]==')'){ //adds to postfix and pops from stack till '(' is found
			while (!(Stack.top() == '(')){
				postfix+=Stack.top();
				Stack.pop();
			}
			Stack.pop(); //pops the '('
			}
		else throw logic_error("Error: Incorrect Expression!"); //incase expression isnt numeric
		}
	while (!Stack.empty()){
		postfix+=Stack.top(); //removes operators from stack till stack is empty
		Stack.pop();
	}
	return postfix; //returns postfix expression
		
	}

//Evaluates the postfix expression
float evaluate(string postfix){
	MyStack<float> Stack; //Creates a stack of type float
	for (int i=0; i<postfix.length();i++){ //iterates through the postfix expression
		if (isdigit(postfix[i])){ 
			int j = postfix[i] - '0'; //If index is an operand, converts the char to an int
			Stack.push(j); //pushes the int into the stack
		}
		else if (isOperator(postfix[i])){ 
			float x=Stack.top(); //float x stores the first top operand in the stack
			Stack.pop();
			float y=Stack.top(); //float y stores the second top operand in the stack
			Stack.pop();
			float output; //float output will store the output for every calculation
			switch (postfix[i]){
			case '+': //if operator is '+', adds the two numbers
				output=y+x;
				break;
			case '-': //if operator is 'i', subtracts x from y
				output=y-x;
				break;
			case '*':
				output=y*x; //if operator is '*', multiplies the two numbers
				break;
			case '/': //if operator is '/', divides y by x
				if (x==0) throw logic_error("Error: Can't divide by zero!"); //if x=0, throws a logic error
				output=y/x;
				break;
			case '^': //if operator is '^', output is y^x
				if (x==0) output=1;
				else{
					output=1;
					for (int k=0; k<x;k++){
						output *= y;
					}
				}
			}
			Stack.push(output); //pushes the ouput of each calculation onto the stack
		}
	}
	return Stack.top(); //we will only have one value left at the end, which will be our answer
}	


